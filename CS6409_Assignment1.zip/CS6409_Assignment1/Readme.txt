Assignment 1 : CS6409
Submitted by,
    Name : Shashank Vats
    ID : 1221010898
    Course : MSc. Data Science


To run the program:
    1. run "scrapy crawl corkwiki"
        Scrap the Cork Wiki page and get all the links and store it in a file named "link.txt"
        Scarp all the links and download the web page as document for further indexing

    2. run the indexer.py file
        Note: Depending upon the environment you might have to comment out or change the JDK path (4th line in code)
        It will move all the Document files to a folder named "DocumentCollection"
        Index it and result will be the document ranked based on the relevence to "Cork City"