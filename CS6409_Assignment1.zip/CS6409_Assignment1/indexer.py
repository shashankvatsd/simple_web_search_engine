import pandas as pd
import os
from movefile import movedocfiles
os.environ["JAVA_HOME"] = "C:\Program Files\Java\jdk-19"            # You may have to change or comment this line based on your system
import pyterrier as pt
from sklearn.feature_extraction.text import TfidfVectorizer

# This will move all the files to a folder to DocumentCollection except Cork City file
movedocfiles.mdf()


if not pt.started(): 
    pt.init()

# Get current working directory
cwd = os.getcwd()

# Read our main file
cork_wiki_file_path = os.path.join(cwd, 'corkwikipage.txt')
with open(cork_wiki_file_path, 'r') as file:
    cork_city_text = file.read()

# path to our DocumentCollection
document_collection_path = os.path.join(cwd, 'DocumentCollection')

# Create data frame to store document file name and its text
# doc_df = pd.DataFrame(columns=['docno','docname', 'doc_text'])

# Getting all the documents name in list
# doc_files = [f for f in os.listdir(document_collection_path) if f.startswith("doc")]

# Reading all the documents and adding the details to the data frame 'doc_df'
# for file in doc_files:
#     file_path = os.path.join(document_collection_path, file)
#     with open(file_path, 'r') as f:
#         text = f.read()
#     doc_df.loc[len(doc_df.index)] = [len(doc_df.index), file, text]


# print(doc_df.iloc[1,:])


# path of index files
index_path = os.path.join(cwd, 'pd_index')
# if os.path.exists(index_path):
#     os.rmdir(index_path)

# Define indexer
pd_indexer = pt.FilesIndexer(index_path)

# Create index reference and pass the data frame
index_ref = pd_indexer.index(document_collection_path)

# Create index from index_ref
index = pt.IndexFactory.of(index_ref)
print(index.getCollectionStatistics().toString()) 

# Create weighted tf-idf model
tfidf = pt.BatchRetrieve(index, wmodel="TF_IDF")
result = tfidf.search('Cork City') 
# print(result)

# Print 10 most relevent document with file name
top10result = result.loc[0:10,['docno','rank','score','query']]
print(top10result)