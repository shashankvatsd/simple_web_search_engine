import os
import shutil

class movedocfiles:

    def mdf():

        cwd = os.getcwd()
        new_folder_name = 'DocumentCollection'
        new_folder_path = os.path.join(cwd,new_folder_name)

        if not os.path.exists(new_folder_path):
            os.mkdir(new_folder_path)

        doc_files = [f for f in os.listdir(cwd) if f.startswith("doc")]

        for doc_file in doc_files:
            shutil.move(os.path.join(cwd, doc_file), os.path.join(new_folder_path, doc_file), copy_function=shutil.copy2)