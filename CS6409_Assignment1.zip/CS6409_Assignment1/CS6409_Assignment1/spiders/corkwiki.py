import scrapy
import re


class CorkwikiSpider(scrapy.Spider):
    name = "corkwiki"
    allowed_domains = ["en.wikipedia.org"]
    start_urls = ["https://en.wikipedia.org/wiki/Cork_(city)"]


    def parse(self, response):

        # Extracting title and all paragraph content from ouw main page
        # And soting them in file named 'corkwikipage.txt'
        title = response.css('title::text').get()
        paragraphs = response.css('p::text').getall()
        filename_cwp = 'corkwikipage.txt'
        with open(filename_cwp, 'w') as file:
            file.write(title)

        with open(filename_cwp, 'a') as file:
            for para in paragraphs:
                # file.write('\n' + para)
                file.write(para)


        # Extracting all the links in paragraph from our main page
        # And storing them in file named 'links.txt' 
        links = response.xpath('//a/@href').getall()
        links = set(links)                                  # To remove duplicates
        filename_link = 'links.txt'
        with open(filename_link, 'w') as file:
            file.write("Extracted Links for Cork City wiki page.")

        with open(filename_link, 'a') as file:
            for link in links:
                file.write('\n' + link)


        # Some internal wiki links does not have domain name in it.
        # Getting those links and adding domain to it before requesting contents from those pages
        regexp_wiki = re.compile(r'/wiki/\w+')

        # To identify links starting with http or https
        regexp_http = re.compile(r'htt\w+')

        for link in links:

            if regexp_wiki.match(link):
                link = 'https://en.wikipedia.org'+link
                yield scrapy.Request(link, callback=self.biopage)

            if regexp_http.match(link):
                yield scrapy.Request(link, callback=self.biopage)
            else:
                continue                                            # not a valid link then skip it





    def biopage(self, response):

        # Extracting title and page content (text from paragraph tag)
        title = response.css('title::text').get()
        details = response.css('p::text').getall()

        # Soring them in files with files name as title of the page
        filename = 'doc - ' + title + '.txt'
        with open(filename,'w') as file:
            file.write(title)

        with open(filename, 'a') as file:
            for d in details:
                # file.write('\n' + d)
                file.write(d)